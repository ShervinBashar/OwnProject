<!DOCTYPE html>
<html>
<head>
    
<title>Heather Bourke</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

.fa {
  padding: 10px;
  font-size: 20px;
  width: 60px;
  text-align: center;
  text-decoration: none;
  margin: 5px 1px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-instagram {
  background: #125688;
  color: white;
}

.fa-pinterest {
  background: #cb2027;
  color: white;
}


body{
   background-color: #A8AAC6;
}
* {
  box-sizing: border-box;
}

.row {
  display: flex;
}

/* Create four equal columns that sits next to each other */
.column {
  flex: 25%;
  padding: 5px;
}

body {font-family: "Raleway", Arial, sans-serif}

</style>
</head>
<body>
  <div class="row">
    <div class="column">
     <!-- <a target="_blank" href="3.jpg"> --><img src="3.jpg" img title="" style="width:100%" onContextMenu="return false;"></a>
</div>

    <div class="column">
     <!-- <a target="_blank" href="4.jpg"> --><img src="4.jpg" img title="" style="width:100%" onContextMenu="return false;"></a>
    </div>
    <div class="column">
      <!--<a target="_blank" href="5.jpg"> --><img src="5.jpg" img title="" style="width:100%" onContextMenu="return false;"></a>
    </div>
    <div class="column">
    <!--  <a target="_blank" href="6.jpg"> --><img src="6.jpg" img title="" style="width:100%" onContextMenu="return false;"></a>
    </div>
  </div>

<!-- !PAGE CONTENT! -->
<div class="w3-content" style="max-width:1500px">

  <!-- Header -->
  <header class="w3-container w3-xlarge w3-padding-24">
    <a href="#" class="w3-left w3-button w3-WhiteSmoke">MY ART</a>
    <a href="#about" class="w3-right w3-button w3-WhiteSmoke">About</a>
  </header>
    </div>
    <div class="w3-content" style="max-width:1500px">
      <header class="w3-container w3-xlarge w3-padding-24">
    <!--<center><a href="morework.php" class=" w3-button w3-WhiteSmoke w3-round-xxlarge">Artworks</a></center><br> -->
    <center><a href="Artworks.php" class=" w3-button w3-WhiteSmoke w3-round-xxlarge">Artworks</a></center>




<!-- Footer / About Section -->
<footer class="w3-padding-64 w3-center" id="about">
  <h2><font color="black" face="Brush Script MT" size="25"><b><i>Heather Bourke</i></b></font></h2>
  <img style="border-radius: 50%;" src="id.jpg" class="w3-image w3-padding-32" width="300" height="300">
  <main>
    <form style="margin:auto;width:60%" class="contact-form" action="cf.php" method="post">
    
    <p></p><br>
    <p class="w3-large w3-text-pink">Contact Form</p>
    <div class="w3-section">
      <label><b>Name</b></label>
     <input class="w3-input w3-border" type="text" name="name">
    </div>
    <div class="w3-section">
      <label><b>Email</b></label>
      <input class="w3-input w3-border" type="text" name="email">
    </div>
    <div class="w3-section">
      <label><b>Message</b></label>
      <textarea class="w3-input w3-border" name="message"></textarea>
    </div>
    <button type="submit" class="w3-button w3-block w3-dark-grey" name="submit">Send</button>
  </form>
</main>
<br>
</footer>
<!--<a href="3.jpg" download>
  <img src="3.jpg" height="50, width="50">
</a>-->

<center>
<a href="https://www.facebook.com/heather.bourkebashar" class="fa fa-facebook" rel="noopener noreferrer" target="_blank"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-instagram"></a>
<a href="#" class="fa fa-pinterest"></a>
</center>
<center><p><font size="2">&copy; Heather Bourke-Bashar 2021</font></p></center>
</body>
</html>
