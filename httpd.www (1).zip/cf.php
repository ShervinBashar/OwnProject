<?php

if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $mailFrom = $_POST['email'];
  $message = $_POST['message'];
  
  $mailTo = "artist@heatherbourke.one";
  $headers = "From: ".$mailFrom;
 
 $txt = "You have received an email from ".$name.".\n\n";
 $subject = $message;
 
  mail($mailTo, $txt, $subject, $headers);
  header("Location: index.php?mailsend");
}


?>
